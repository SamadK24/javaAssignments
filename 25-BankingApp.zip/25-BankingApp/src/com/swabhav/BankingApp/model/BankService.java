package com.swabhav.BankingApp.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BankService {
    private List<Accounts> accounts = new ArrayList<>();
    private List<Transactions> transactions = new ArrayList<>();
    private int accountCounter = 1;

    public void addAccount(String name, String username, String password, double balance) {
        Accounts acc = new Accounts();
        acc.setAccId(accountCounter++);
        acc.setName(name);
        acc.setUsername(username);
        acc.setPassword(password);
        acc.setBalance(balance);
        acc.setActive(true);
        accounts.add(acc);
    }

    public void addAccountWithCredentials(Accounts acc) {
        acc.setAccId(accountCounter++);
        acc.setActive(true);
        accounts.add(acc);
    }

    public boolean isValidAccount(int accId) {
        return accounts.stream().anyMatch(a -> a.getAccId() == accId && a.isActive());
    }

    public int authenticateCustomer(String username, String password) {
        String query = "SELECT acc_id FROM accounts WHERE username=? AND password=? AND is_active=1";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("acc_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }


    public void checkBalance(int accId) {
        for (Accounts acc : accounts) {
            if (acc.getAccId() == accId) {
                System.out.println("Your current balance is: ₹" + acc.getBalance());
                return;
            }
        }
    }

    public void deposit(int accId, double amount) throws InvalidAmountException {
        if (amount <= 0) throw new InvalidAmountException("Amount must be positive");
        for (Accounts acc : accounts) {
            if (acc.getAccId() == accId) {
                acc.setBalance(acc.getBalance() + amount);
                transactions.add(new Transactions("Deposit", accId, amount));
                System.out.println("₹" + amount + " deposited successfully.");
                return;
            }
        }
    }

    public void withDraw(int accId, double amount) throws InvalidAmountException {
        if (amount <= 0) throw new InvalidAmountException("Amount must be positive");

        for (Accounts acc : accounts) {
            if (acc.getAccId() == accId) {
                if (acc.getBalance() < amount)
                    throw new InvalidAmountException("Insufficient balance");

                acc.setBalance(acc.getBalance() - amount);
                transactions.add(new Transactions("Withdraw", accId, amount));
                System.out.println("₹" + amount + " withdrawn successfully.");
                return;
            }
        }
    }

    public void transferMoney(int fromAccId, int toAccId, double amount) throws InvalidAmountException {
        if (amount <= 0) throw new InvalidAmountException("Amount must be positive");

        Accounts sender = null, receiver = null;

        for (Accounts acc : accounts) {
            if (acc.getAccId() == fromAccId) sender = acc;
            if (acc.getAccId() == toAccId) receiver = acc;
        }

        if (sender == null || receiver == null)
            throw new InvalidAmountException("Invalid account ID(s)");

        if (sender.getBalance() < amount)
            throw new InvalidAmountException("Insufficient balance for transfer");

        sender.setBalance(sender.getBalance() - amount);
        receiver.setBalance(receiver.getBalance() + amount);

        transactions.add(new Transactions("Transfer to " + toAccId, fromAccId, amount));
        transactions.add(new Transactions("Transfer from " + fromAccId, toAccId, amount));
        System.out.println("₹" + amount + " transferred to Account ID: " + toAccId);
    }

    public void transactionHistory(int accId) {
        List<Transactions> accTransactions = transactions.stream()
            .filter(t -> t.getAcc_id() == accId)
            .collect(Collectors.toList());

        if (accTransactions.isEmpty()) {
            System.out.println("No transactions found.");
            return;
        }

        System.out.println("Transaction History:");
        for (Transactions t : accTransactions) {
            System.out.println(t.getType() + " - ₹" + t.getAmount());
        }
    }

    public void viewAllAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts found.");
            return;
        }

        for (Accounts acc : accounts) {
            System.out.println("ID: " + acc.getAccId() +
                " | Name: " + acc.getName() +
                " | Username: " + acc.getUsername() +
                " | Balance: ₹" + acc.getBalance());
        }
    }
}
