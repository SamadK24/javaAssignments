package com.swabhav.BankingApp.model;

public enum TransactionType {
 WITHDRAW,DEPOSIT,TRANSFER;
}
